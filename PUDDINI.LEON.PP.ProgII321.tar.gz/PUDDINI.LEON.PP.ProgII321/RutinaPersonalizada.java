public class RutinaPersonalizada extends Actividad implements Programable, Informable {

    private int duracionSemanas;

    public RutinaPersonalizada(String nombre, String entrenador, NivelIntensidad nivel, int duracionSemanas) {
        super(nombre, entrenador, nivel);
        this.duracionSemanas = duracionSemanas;
    }

    public int getDuracionSemanas() {
        return duracionSemanas;
    }

    @Override
    public String programar() {
        return "Se programo la rutina personalizada: " + getNombre();
    }

    @Override
    public String generarInforme() {
        return "Informe de rutina personalizada: " + getNombre() + ". Duracion estimada: " + duracionSemanas + " semanas.";
    }

    @Override
    public String toString() {
        return "RutinaPersonalizada [nombre=" + getNombre() + ", entrenador=" + getEntrenador() + ", intensidad=" + getNivelIntensidad() + ", duracionSemanas=" + duracionSemanas + "]";
    }
}
