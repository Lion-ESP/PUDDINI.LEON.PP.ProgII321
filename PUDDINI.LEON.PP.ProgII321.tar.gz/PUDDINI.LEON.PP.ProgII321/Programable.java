// actividades que pueden ser programadas.
// El método devuelve el mensaje de confirmación
public interface Programable {
    String programar();
}
