import java.util.ArrayList;
import java.util.List;

/**
 * Gestiona el catálogo de actividades del centro deportivo.
 * Garantiza que no existan actividades duplicadas (mismo nombre y entrenador).
 */
public class CentroEntrenamiento {

    private String nombre;
    private List<Actividad> actividades;

    public CentroEntrenamiento(String nombre) {
        this.nombre = nombre;
        this.actividades = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }


    // Agrega la actividad al catálogo si no existe otra con igual nombre y entrenador.
    // Lanza un ActividadDuplicadaException si ya existe una actividad equivalente
    public void agregarActividad(Actividad actividad) throws ActividadDuplicadaException {
        if (actividades.contains(actividad)) {
            throw new ActividadDuplicadaException(
                "Ya existe una actividad con nombre '" + actividad.getNombre() +
                "' y entrenador '" + actividad.getEntrenador() + "'."
            );
        }
        actividades.add(actividad);
    }


    public List<Actividad> obtenerActividades() {
        // deuelve una copia para quien llama al método no pueda modificar la lista interna
        return new ArrayList<>(actividades);
    }

    public List<Actividad> filtrarPorNivel(NivelIntensidad nivel) {
        List<Actividad> filtradas = new ArrayList<>();
        for (Actividad a : actividades) {
            if (a.getNivelIntensidad() == nivel) {
                filtradas.add(a);
            }
        }
        return filtradas;
    }
}
