public enum NivelIntensidad {
    BAJA, MEDIA, ALTA
}
