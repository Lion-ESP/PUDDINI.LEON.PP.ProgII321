// método que devuelve el texto del informe; la impresión
public interface Informable {
    String generarInforme();
}
