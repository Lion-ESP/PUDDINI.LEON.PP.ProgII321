import java.util.Objects;

//Superclase abstracta de todas las actividades del centro.
// Define los atributos comunes y establece el criterio de igualdad: dos actividades son duplicadas si tienen el mismo nombre y el mismo entrenador responsable.
public abstract class Actividad {

    private String nombre;
    private String entrenador;
    private NivelIntensidad nivelIntensidad;

    public Actividad(String nombre, String entrenador, NivelIntensidad nivelIntensidad) {
        this.nombre = nombre;
        this.entrenador = entrenador;
        this.nivelIntensidad = nivelIntensidad;
    }

    public String getNombre() { return nombre; }
    public String getEntrenador() { return entrenador; }
    public NivelIntensidad getNivelIntensidad() { return nivelIntensidad; }


     // Dos actividades son iguales si comparten nombre y entrenador.
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Actividad)) return false;
        Actividad otra = (Actividad) o;
        return Objects.equals(nombre, otra.nombre) && Objects.equals(entrenador, otra.entrenador);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, entrenador);
    }

    @Override
    public abstract String toString();
}
