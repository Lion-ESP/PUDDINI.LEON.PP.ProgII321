public class EvaluacionFisica extends Actividad implements Informable {

    private int puntaje;

    public EvaluacionFisica(String nombre, String entrenador, NivelIntensidad nivel, int puntaje) {
        super(nombre, entrenador, nivel);
        this.puntaje = puntaje;
    }

    public int getPuntaje() {
        return puntaje;
    }

    @Override
    public String generarInforme() {
        return "Informe de evaluacion fisica: " + getNombre() + ". Puntaje obtenido: " + puntaje + "/100.";
    }

    @Override
    public String toString() {
        return "EvaluacionFisica [nombre=" + getNombre() + ", entrenador=" + getEntrenador() +  ", intensidad=" + getNivelIntensidad() + ", puntaje=" + puntaje + "]";
    }
}
