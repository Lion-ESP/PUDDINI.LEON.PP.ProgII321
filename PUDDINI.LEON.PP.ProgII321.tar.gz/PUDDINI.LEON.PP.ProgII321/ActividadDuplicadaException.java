public class ActividadDuplicadaException extends Exception {

    public ActividadDuplicadaException(String mensaje) {
        super(mensaje);
    }
}
